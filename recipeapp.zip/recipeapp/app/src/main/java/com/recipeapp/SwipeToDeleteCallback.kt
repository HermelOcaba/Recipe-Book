import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.recipeapp.RecipeAdapter

class SwipeToDeleteCallback(
    private val adapter: RecipeAdapter
) : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {

    override fun onMove(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        target: RecyclerView.ViewHolder
    ): Boolean = false

    override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
        val position = viewHolder.adapterPosition
        val item = (adapter as RecipeAdapter).getItemAt(position)
        if (item is ListItem.RecipeItem) {
            adapter.removeRecipe(item.recipe)
        }
    }

    override fun getSwipeDirs(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder
    ): Int {
        return if (viewHolder is RecipeAdapter.RecipeViewHolder) {
            super.getSwipeDirs(recyclerView, viewHolder)
        } else {
            0
        }
    }
}

// Add this extension function to RecipeAdapter
private fun RecipeAdapter.getItemAt(position: Int): ListItem {
    val field = this::class.java.getDeclaredField("items")
    field.isAccessible = true
    @Suppress("UNCHECKED_CAST")
    val items = field.get(this) as List<ListItem>
    return items[position]
}
package com.recipeapp

import Flavor
import ListItem
import Recipe
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecipeAdapter(
    private val onRecipeClick: (Recipe) -> Unit,
    private val onRecipeSwipe: (Recipe) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<ListItem>()

    companion object {
        private const val TYPE_FLAVOR_TITLE = 0
        private const val TYPE_RECIPE = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (items[position]) {
            is ListItem.FlavorTitle -> TYPE_FLAVOR_TITLE
            is ListItem.RecipeItem -> TYPE_RECIPE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_FLAVOR_TITLE -> FlavorTitleViewHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_flavor_title, parent, false)
            )
            TYPE_RECIPE -> RecipeViewHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_recipe, parent, false)
            )
            else -> throw IllegalArgumentException("Unknown view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is FlavorTitleViewHolder -> holder.bind((items[position] as ListItem.FlavorTitle).flavor)
            is RecipeViewHolder -> {
                val recipe = (items[position] as ListItem.RecipeItem).recipe
                holder.bind(recipe)
                holder.itemView.setOnClickListener { onRecipeClick(recipe) }
            }
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateRecipes(recipes: List<Recipe>) {
        items.clear()

        // Group recipes by flavor
        val groupedRecipes = recipes.groupBy { it.flavor }

        // Add flavor titles and recipes
        Flavor.values().forEach { flavor ->
            val flavorRecipes = groupedRecipes[flavor] ?: emptyList()
            if (flavorRecipes.isNotEmpty()) {
                items.add(ListItem.FlavorTitle(flavor))
                items.addAll(flavorRecipes.map { ListItem.RecipeItem(it) })
            }
        }

        notifyDataSetChanged()
    }

    fun removeRecipe(recipe: Recipe) {
        val recipes = items.filterIsInstance<ListItem.RecipeItem>().map { it.recipe }
        val updatedRecipes = recipes.toMutableList().apply { remove(recipe) }
        updateRecipes(updatedRecipes)
        onRecipeSwipe(recipe)
    }

    inner class FlavorTitleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvFlavorTitle: TextView = itemView.findViewById(R.id.tvFlavorTitle)

        fun bind(flavor: Flavor) {
            tvFlavorTitle.text = when (flavor) {
                Flavor.SWEET -> "Sweet Recipes"
                Flavor.SAVORY -> "Savory Recipes"
            }
        }
    }

    inner class RecipeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRecipeTitle: TextView = itemView.findViewById(R.id.tvRecipeTitle)

        fun bind(recipe: Recipe) {
            tvRecipeTitle.text = recipe.title
        }
    }
}